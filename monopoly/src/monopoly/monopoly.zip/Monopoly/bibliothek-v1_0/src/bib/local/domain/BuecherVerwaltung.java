package bib.local.domain;

import java.io.IOException;

import bib.local.domain.exceptions.BuchExistiertBereitsException;
import bib.local.persistence.FilePersistenceManager;
import bib.local.persistence.PersistenceManager;
import bib.local.valueobjects.Buch;
import bib.local.valueobjects.BuchListe;


/**
 * Klasse zur Verwaltung von Büchern.
 * 
 * @author teschke
 * @version 1 (Verwaltung in verketteter Liste)
 */
public class BuecherVerwaltung {

	// Verwaltung des Buchbestands in einer verketteten Liste
	private BuchListe buchBestand = new BuchListe();

	// Persistenz-Schnittstelle, die für die Details des Dateizugriffs verantwortlich ist
	private PersistenceManager pm = new FilePersistenceManager();
	
	/**
	 * Methode zum Einlesen von Buchdaten aus einer Datei.
	 * 
	 * @param datei Datei, die einzulesenden Bücherbestand enthält
	 * @throws IOException
	 */
	public void liesDaten(String datei) throws IOException {
		// PersistenzManager für Lesevorgänge öffnen
		pm.openForReading(datei);

		Buch einBuch;
		do {
			// Buch-Objekt einlesen
			einBuch = pm.ladeBuch();
			if (einBuch != null) {
				// Buch in Liste einfügen
				try {
					einfuegen(einBuch);
				} catch (BuchExistiertBereitsException e1) {
					// Kann hier eigentlich nicht auftreten,
					// daher auch keine Fehlerbehandlung...
				}
			}
		} while (einBuch != null);

		// Persistenz-Schnittstelle wieder schließen
		pm.close();
	}

	/**
	 * Methode zum Schreiben der Buchdaten in eine Datei.
	 * 
	 * @param datei Datei, in die der Bücherbestand geschrieben werden soll
	 * @throws IOException
	 */
	public void schreibeDaten(String datei) throws IOException  {
		// PersistenzManager für Schreibvorgänge öffnen
		pm.openForWriting(datei);

		BuchListe liste = buchBestand;
		while (liste != null) {
			Buch b = liste.gibErstesBuch();
			if (b != null) {
				// speichern
				pm.speichereBuch(b);
			}
			liste = liste.gibRestlicheBuecher();
		}
		
		// Persistenz-Schnittstelle wieder schließen
		pm.close();
	}
		
	/**
	 * Methode, die ein Buch an das Ende der Bücherliste einfügt.
	 * 
	 * @param einBuch das einzufügende Buch
	 * @throws BuchExistiertBereitsException wenn das Buch bereits existiert
	 */
	public void einfuegen(Buch einBuch) throws BuchExistiertBereitsException {
		// das übernimmt die BuchListe:
		buchBestand.einfuegen(einBuch);
	}

	/**
	 * Methode, die anhand eines Titels nach Büchern sucht. Es wird eine Liste von Büchern
	 * zurückgegeben, die alle Bücher mit exakt übereinstimmendem Titel enthält.
	 * 
	 * @param titel Titel des gesuchten Buchs
	 * @return Liste der Bücher mit gesuchtem Titel (evtl. leer)
	 */
	public BuchListe sucheBuecher(String titel) {
		BuchListe suchErg = new BuchListe();
		BuchListe aktBuchListenElt = buchBestand;
		while (aktBuchListenElt != null) {
			Buch aktBuch = aktBuchListenElt.gibErstesBuch(); 
			if (aktBuch.getTitel().equals(titel)) {
				// gefundenes Buch in Suchergebnis eintragen
				try {
					suchErg.einfuegen(aktBuch);
				} catch (BuchExistiertBereitsException e) {
					// Exception kann hier eigentlich nie auftreten.
				}
			}
			aktBuchListenElt = aktBuchListenElt.gibRestlicheBuecher();
		}
		return suchErg;
	}
	
	/**
	 * Methode, die den Bücherbestand zurückgibt.
	 */
	public BuchListe getBuchBestand() {
		return buchBestand;
	}
	
	// TODO: Weitere Methoden, z.B. zum Auslesen und Entfernen von Büchern
	// ...
}
