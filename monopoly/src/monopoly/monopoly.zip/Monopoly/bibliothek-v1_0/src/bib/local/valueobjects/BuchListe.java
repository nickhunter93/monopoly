package bib.local.valueobjects;

import bib.local.domain.exceptions.BuchExistiertBereitsException;

/**
 * (Nicht ganz) abstrakter Datentyp zur Verwaltung von Büchern in einer Liste.
 * 
 * @author teschke
 * @version 1 (verkettete Liste)
 */
public class BuchListe {

	// das Listenelement
	private Buch buch = null;

	// Verweis auf Rest der Liste. 
	// Der Rest der Liste ist wieder eine BuchListe, 
	// wobei die um ein Element (nämlich das obige Buch) kürzer ist!
	private BuchListe next = null;
		
	/**
	 * Methode, die das erste Buch der Liste zurückgibt.
	 */
	public Buch gibErstesBuch() {
		return buch;
	}
	
	/**
	 * Methode, die die Liste der verbleibenden Bücher zurückgibt (d.h. ohne das erste Buch).
	 */
	public BuchListe gibRestlicheBuecher() {
		return next;
	}

	/**
	 * Methode, die ein Buch an das Ende der Bücherliste einfügt.
	 * 
	 * @param einBuch das einzufügende Buch
	 * @throws BuchExistiertBereitsException wenn das Buch bereits existiert
	 */
	public void einfuegen(Buch einBuch) throws BuchExistiertBereitsException {
		// Liste noch leer, d.h. auch kein erstes Buch?
		if (buch == null) {
			buch = einBuch;
		}
		else {
			// Stimmt das neue Buch mit dem aktuell betrachteten Listenelement
			// überein? Dann Fehler, weil Buch nur einmal in der Liste vorkommen soll.
			if (buch.equals(einBuch))
				throw new BuchExistiertBereitsException(einBuch, " - in 'einfuegen()'");

			// Sind wir am Listenende?
			if (next == null) {
				// Ja: dann neue Restliste mit Buch als Element erzeugen
				next = new BuchListe();
			}
			// Buch in existierende Restliste einfügen (rekursiver Aufruf!)
			next.einfuegen(einBuch);
		}
	}	

	// TODO: Weitere Methoden, z.B. zum Entfernen von Büchern
	// ...

	/** 
	 * Standard-Methode von Object überschrieben.
	 * Methode wird immer automatisch aufgerufen, wenn ein BuchListe-Objekt als String
	 * benutzt wird (z.B. in println(...);)
	 * 
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		String result = "";
		// Der Zeilenumbruch wird auf verschiedenen Betriebssystemen durch
		// unterschiedliche Zeichenketten (sog. Escape-Sequenzen) erreicht,
		// unter Windows z.B. "\n"
		String zeilenEnde = System.getProperty("line.separator");
		BuchListe aktBuchElt = this;
		if (aktBuchElt.buch == null)
			return "Liste ist leer." + zeilenEnde;
		else {
			while (aktBuchElt != null) {
				result += aktBuchElt.buch + zeilenEnde;
				aktBuchElt = aktBuchElt.next;
			}
		}
		return result;
	}
}
